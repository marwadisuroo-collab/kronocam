import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Wraps a rewarded ad that the user watches to unlock the stamp editor.
///
/// Uses Google's public TEST ad unit IDs so the app runs and shows a real
/// "Test Ad" out of the box. Replace [_androidAdUnitId] / [_iosAdUnitId]
/// with your own AdMob rewarded ad unit IDs before publishing — see
/// README.md for the exact steps.
class AdService {
  AdService._();
  static final AdService instance = AdService._();

  static const _androidAdUnitId = 'ca-app-pub-3940256099942544/5224354917';
  static const _iosAdUnitId = 'ca-app-pub-3940256099942544/1712485313';

  RewardedAd? _rewardedAd;
  bool _isLoading = false;

  String get _adUnitId =>
      Platform.isAndroid ? _androidAdUnitId : _iosAdUnitId;

  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    _loadAd();
  }

  void _loadAd() {
    if (_isLoading) return;
    _isLoading = true;
    RewardedAd.load(
      adUnitId: _adUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isLoading = false;
        },
        onAdFailedToLoad: (error) {
          _rewardedAd = null;
          _isLoading = false;
        },
      ),
    );
  }

  bool get isReady => _rewardedAd != null;

  /// Shows the rewarded ad. Calls [onReward] once the user has watched it
  /// through and earned the reward. If no ad is available (e.g. offline,
  /// or running in a sandbox without real ad fill), [onReward] is still
  /// called after a short delay so the feature never gets permanently
  /// stuck — swap this fallback out once you have production ad fill.
  Future<void> showAd({required VoidCallback onReward}) async {
    final ad = _rewardedAd;
    if (ad == null) {
      onReward();
      _loadAd();
      return;
    }

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
        _loadAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _rewardedAd = null;
        _loadAd();
        onReward();
      },
    );

    await ad.show(
      onUserEarnedReward: (ad, reward) => onReward(),
    );
  }
}
